/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_180(unsigned *p)
{
    *p = 3347662936U;
}

void setval_227(unsigned *p)
{
    *p = 2438489601U;
}

unsigned getval_209()
{
    return 2425393752U;
}

void setval_140(unsigned *p)
{
    *p = 3284601160U;
}

void setval_490(unsigned *p)
{
    *p = 3013854040U;
}

unsigned getval_287()
{
    return 2428995912U;
}

unsigned getval_170()
{
    return 2425378846U;
}

unsigned getval_231()
{
    return 2428996424U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_211(unsigned *p)
{
    *p = 3677933961U;
}

unsigned addval_187(unsigned x)
{
    return x + 3225993865U;
}

void setval_431(unsigned *p)
{
    *p = 3252717896U;
}

unsigned getval_322()
{
    return 3221802635U;
}

void setval_469(unsigned *p)
{
    *p = 3381972617U;
}

unsigned addval_436(unsigned x)
{
    return x + 3221802635U;
}

unsigned getval_220()
{
    return 3284306131U;
}

unsigned getval_311()
{
    return 3526938889U;
}

unsigned getval_121()
{
    return 2429652306U;
}

unsigned getval_179()
{
    return 3378565513U;
}

unsigned addval_241(unsigned x)
{
    return x + 3221799565U;
}

unsigned getval_409()
{
    return 3682913929U;
}

unsigned addval_367(unsigned x)
{
    return x + 3281044137U;
}

void setval_430(unsigned *p)
{
    *p = 3374367369U;
}

unsigned addval_454(unsigned x)
{
    return x + 3435385225U;
}

unsigned addval_455(unsigned x)
{
    return x + 3286272072U;
}

unsigned getval_186()
{
    return 3523789449U;
}

unsigned addval_377(unsigned x)
{
    return x + 3677933833U;
}

void setval_161(unsigned *p)
{
    *p = 2497743176U;
}

void setval_171(unsigned *p)
{
    *p = 3373846921U;
}

void setval_164(unsigned *p)
{
    *p = 3381972617U;
}

void setval_373(unsigned *p)
{
    *p = 3683959433U;
}

unsigned addval_437(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_230(unsigned x)
{
    return x + 3767093288U;
}

unsigned addval_397(unsigned x)
{
    return x + 3675836041U;
}

unsigned getval_138()
{
    return 3374371201U;
}

unsigned addval_346(unsigned x)
{
    return x + 180539017U;
}

void setval_429(unsigned *p)
{
    *p = 3252717896U;
}

unsigned getval_492()
{
    return 3269495112U;
}

unsigned addval_427(unsigned x)
{
    return x + 3224948361U;
}

void setval_252(unsigned *p)
{
    *p = 3767101514U;
}

unsigned addval_339(unsigned x)
{
    return x + 2428666174U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
