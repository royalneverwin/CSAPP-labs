/*1900011102 王新昊*/

/*main idea: 使用tiny.c的代码作为基础，先实现Part 1，利用read_request，
read_requesthdrs，parse_head，parse_url，Send函数实现题目所要求的操作；
再利用Posix的thread实现Part 2，就是简单的给每一个请求创建一个新线程；最后利
用C的pthread_rwlock和信号量mutex实现Part 3，其中pthread_rwlock解决“读者、
写者问题”，mutex用于实现读时更新cache的time变量的互斥。*/

#include "csapp.h"
#include <stdio.h>
/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400

/*some string size in Req*/
#define MAX_HOSTNAME_LENGTH 128
#define MAXS_PORT_LENGTH 16
#define MAX_KEY_LENGTH 32
#define MAX_VALUE_LENGTH 512
#define MAX_HEAD_CNT 32

/*block number of caches*/
#define CACHE_CNT 10
/*struct that needed when read_request*/
struct ReqLine{
    char hostname[MAX_HOSTNAME_LENGTH];
    char port[MAXS_PORT_LENGTH];
    char path[MAXLINE];
};

struct ReqHead{
    char key[MAX_KEY_LENGTH];
    char value[MAX_VALUE_LENGTH];
};

/*struct of a cache block*/
struct Cache{
    int valid;
    char *sig;
    char *buf;
    size_t size;
    pthread_rwlock_t lock;  //use systematic read_write lock
    int time;   //use LRU to judge which cache should be evict 
};


struct Cache cache[CACHE_CNT];

/* You won't lose style points for including this long line in your code */
static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";

/*help functions*/
void doit(int fd);
void *thread( void *vargp);
int read_request(rio_t *rp, int fd, char *method, char *url, char *version);
int read_requesthdrs(rio_t *rp, int fd, int *head_address_cnt, struct ReqHead *head, char *hostname);
int parse_url(char *url, struct ReqLine *line, int fd);
int parse_head(char *buf, struct ReqHead *head, int *head_address_cnt, int fd);
int Send(struct ReqLine *line, struct ReqHead *head, int head_address_cnt, int fd);
void init_cache();
void free_cache();
int find_cache(char *sig);
int read_cache(char *sig, int fd);
int find_evict();
void write_cache(char *sig, char *buf, size_t size);

/*lock*/
sem_t mutex;

int main(int argc, char **argv) 
{
    signal(SIGPIPE, SIG_IGN);//ignore SIGPIPE
    Sem_init(&mutex, 0, 1);
    int listenfd;
    int *connfd;
    char hostname[MAXLINE], port[MAXLINE];
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;//big enough to hold any kinds of Socket Address
    pthread_t tid;
    /* Check command line args */
    if (argc != 2) {
	    fprintf(stderr, "usage: %s <port>\n", argv[0]);
	    exit(1);
    }

    init_cache();
    listenfd = Open_listenfd(argv[1]);
    while (1) {
        connfd = (int *)Malloc(sizeof(int));
	    clientlen = sizeof(clientaddr);
	    if((*connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen)) < 0){ //line:netp:tiny:accept
            Free(connfd);
            continue;
        }
        Getnameinfo((SA *) &clientaddr, clientlen, hostname, MAXLINE, 
                    port, MAXLINE, 0);
        Pthread_create(&tid, NULL, thread, connfd);//create a thread
    }
    free_cache();
    return 0;
}
/* $end tinymain */

/*
 *thread - funtion that a thread should implement
 *
 */
/* $begin thread */
void *thread( void *vargp){
    Pthread_detach(pthread_self());//detach
    int connfd = *((int *)vargp);
    Free(vargp);
    doit(connfd);
    Close(connfd);
    return NULL;
}
/* $end thread */

/*
 * doit - handle one HTTP request/response transaction
 */
/* $begin doit */
void doit(int fd) 
{
    int head_address_cnt = 0;
    int clientfd;
    int size; //count if content can be stored in cache
    struct ReqLine line;
    struct ReqHead head[MAX_HEAD_CNT];
    char method[MAXLINE], url[MAXLINE], version[MAXLINE];
    char buf[MAX_OBJECT_SIZE];
    char sig[MAXLINE];
    char cache_buf[MAX_OBJECT_SIZE];
    rio_t rio;
    /* Read request line*/
    if(read_request(&rio, fd, method, url, version) == -1){              //line:netp:doit:readrequesthdrs
        return;
    }
    /* Parse URL from GET request */
    if(parse_url(url, &line, fd) == -1){       //line:netp:doit:staticcheck
	    return;        
    }
    /*Read request headers*/
    if(read_requesthdrs(&rio, fd, &head_address_cnt, head, line.hostname) == -1){
        return;
    }    

    strcpy(sig, line.hostname);
    strcpy(sig + strlen(sig), line.path);
    if(read_cache(sig, fd)){
        printf("read from cache.\n");
        return;
    }
    if((clientfd = Send(&line, head, head_address_cnt, fd)) == -1){
        return;
    }
    size = 0;
    /*receive feedback from web server*/
    int n;
    Rio_readinitb(&rio, clientfd);
    while((n = Rio_readlineb(&rio, buf, MAX_OBJECT_SIZE)) ){
        Rio_writen(fd, buf, n);
        if(size + n <= MAX_OBJECT_SIZE){
            memcpy(cache_buf + size, buf, n);
            size += n;
        }
    }
    if(size <= MAX_OBJECT_SIZE){
        write_cache(sig, cache_buf, size);
    }
    Close(clientfd);
}
/* $end doit */

/*
 * read_request - read HTTP request line
 */
/* $begin read_request */
int read_request(rio_t *rp, int fd, char *method, char *url, char *version) 
{
    char buf[MAX_OBJECT_SIZE];
    Rio_readinitb(rp, fd);
    if (!Rio_readlineb(rp, buf, MAXLINE)){  //line:netp:doit:readrequest
        printf("EOF ERROR\n");
        return -1;
    }
    if(sscanf(buf, "%s %s %s", method, url, version) != 3){      //line:netp:doit:parserequest
        printf("FORMAT ERROR\n");
        return -1;
    }
    if (strcasecmp(method, "GET")) {                     //line:netp:doit:beginrequesterr
        printf("PARSE METHOD ERROR\n");
        return -1;
    }                                                    //line:netp:doit:endrequesterr
    return 0;
}
/* $end read_request */


/*
 * read_requesthdrs - read HTTP request headers
 */
/* $begin read_requesthrs */
int read_requesthdrs(rio_t *rp, int fd, int *head_address_cnt, struct ReqHead *head, char *hostname)
{
    /*read head address*/
    char buf[MAX_OBJECT_SIZE];
    int if_host = 0;    //judge if host is default
    Rio_readlineb(rp, buf, MAXLINE);
    while(strcmp(buf, "\r\n")) {          //line:netp:readhdrs:checkterm
        if(!strstr(buf, "User-Agent:") && !strstr(buf, "Connection:") && !strstr(buf, "Proxy-Connection:")){
            if(strstr(buf, "Host:")){
                if_host = 1;
            }
            if(parse_head(buf, head + (*head_address_cnt), head_address_cnt, fd) == -1){
                return -1;
            }
        }
        Rio_readlineb(rp, buf, MAXLINE);
    }
    /*add Host header*/
    if(!if_host){
        strcpy(head[*head_address_cnt].key, "Host");
        strcpy(head[*head_address_cnt].value, hostname);
        strcpy(head[*head_address_cnt].value + strlen(hostname), "\r\n");//need \r\n in the last
        (*head_address_cnt)++;
    }
    /*add User-Agent header*/
    strcpy(head[*head_address_cnt].key, "User-Agent");
    strcpy(head[*head_address_cnt].value, user_agent_hdr);//don't need \r\n in the last
    (*head_address_cnt)++;
    /*add Conection header*/
    strcpy(head[*head_address_cnt].key, "Connection");
    strcpy(head[*head_address_cnt].value, "close\r\n");
    (*head_address_cnt)++;
    /*add Proxy-Connection header*/
    strcpy(head[*head_address_cnt].key, "Proxy-Connection");
    strcpy(head[*head_address_cnt].value, "close\r\n");
    (*head_address_cnt)++;
    return 0;
}
/* $end read_requesthdrs */


/*
 * parse_url - parse URL into hostname, port and path,
 *             return 0 if right, -1 if wrong
 */
/* $begin parse_url */
int parse_url(char *url, struct ReqLine *line, int fd) 
{
    char *path;
    char *port;
    if(strstr(url, "http://") != url){//format error
        printf("URL HOST ERROR\n");
        return -1;
    }
    url += strlen("http://");
    if(!(path = strstr(url, "/"))){
        printf("URL PATH ERROR\n");
        return -1;
    }
    strcpy(line->path, path);
    *path = '\0';
    if((port = strstr(url, ":"))){
        strcpy(line->port, port+1);
        *port = '\0';
    }
    else{
        strcpy(line->port, "80");
    }
    strcpy(line->hostname, url);
    return 0;
}
/* $end parse_url */

/*
 * parse_haed - parse HEADERs into key and  value.
 *              return 0 if right, -1 if wrong
 */
/* $begin parse_head */
int parse_head(char *buf, struct ReqHead *head, int *head_address_cnt, int fd){
    char *value;
    if(!(value = strstr(buf, ":"))){
        printf("URL HEAD ERROR\n");
        return -1;
    }
    *value = '\0';
    strcpy(head->key, buf);
    strcpy(head->value, value+2);  //behind ':' there is also a ' ' && there is \r\n in buf[MAXLINE]
    (*head_address_cnt)++;
    return 0;
}
/* $end parse_head */

/*
 *Send - build a clientfd and send request to web server
 *
 */
/* $begin Send */
int Send(struct ReqLine *line, struct ReqHead *head, int head_address_cnt, int fd){
    int clientfd;
    char buf[MAX_OBJECT_SIZE];
    rio_t rio;
    if((clientfd = Open_clientfd(line->hostname, line->port))  == -1){
        printf("OPEN CLIENTFD ERROR\n");
        return -1;
    }
    Rio_readinitb(&rio, clientfd);
    sprintf(buf, "GET %s HTTP/1.0\r\n", line->path);
    for(int  i = 0; i < head_address_cnt; i++){
        sprintf(buf, "%s%s: %s", buf, head[i].key, head[i].value);//no need \r\n
    }
    sprintf(buf, "%s\r\n", buf);//show the end of the headers
    Rio_writen(clientfd, buf, strlen(buf));
    return clientfd;
}
/* $end Send */

/*
 *init_cache - initiate cache blocks
 *
 */
 /* $begin init_cache */
void init_cache(){
    for(int i = 0; i < CACHE_CNT; i++){
        cache[i].valid = 0;
        cache[i].size = 0;
        pthread_rwlock_init(&(cache[i].lock), NULL);   //initiate read_write lock
        cache[i].sig = (char *)Malloc(sizeof(char) * MAXLINE);
        cache[i].buf = (char *)Malloc(sizeof(char) * MAX_OBJECT_SIZE);
        cache[i].time = 0;
    }
}
/* $end init_cache */

/*
 *free_cache - free cache blocks
 *
 */
/* $begin free_cache */
void free_cache(){
    for(int i = 0; i < CACHE_CNT; i++){
        pthread_rwlock_destroy(&(cache[i].lock));   //delete read_write lock
        Free(cache[i].sig);
        Free(cache[i].buf);
    }
}
/* $end free_cache */

/*
 *find_cache - find cache that sig fits, 
 *             return cache_index if find, -1 if not
 */
/* $begin find_cache */
int find_cache(char *sig){
    int index = -1;
    for(int i = 0; i < CACHE_CNT; i++){
        pthread_rwlock_rdlock(&(cache[i].lock));    //lock
        if(cache[i].valid && !strcmp(cache[i].sig, sig)){
            index = i;
        }
        pthread_rwlock_unlock(&(cache[i].lock));    //unlock
        if(index != -1){
            break;
        }
    }
    return index;
}
/* $end find_cache */

/*
 *read_cache - read cache to find if the contents are in cache, if are, send them to clients 
 *             return 1 if true, 0 if not
 */
/* $begin read_cache */
int read_cache(char *sig, int fd){
    int index;
    if((index = find_cache(sig)) == -1){
        return 0;
    } 
    pthread_rwlock_rdlock(&(cache[index].lock));//lock
    if(strcmp(sig, cache[index].sig)){  //cache block is covered again after find_cache
        pthread_rwlock_unlock(&(cache[index].lock));//unlock
        return 0;
    }
    P(&mutex);//lock 2
    cache[index].time = 0;
    for(int i = 0; i < CACHE_CNT; i++){  //update time
        cache[i].time++;
    }
    V(&mutex);// unlock 2
    Rio_writen(fd, cache[index].buf, cache[index].size);
    pthread_rwlock_unlock(&(cache[index].lock));//unlock
    return 1;
}
/* $end read_cache */

/*
 *find_evict - find cache that should be evicted, or a cache that is not occupied
 *             return cache_indext
 */
/* $begin find_evict */
int find_evict(){
    int max = 0;
    int index = 0;
    for(int i = 0; i < CACHE_CNT; i++){
        pthread_rwlock_wrlock(&(cache[i].lock));//lock
        if(!cache[i].valid){
            pthread_rwlock_unlock(&(cache[i].lock));//unlock
            return i;
        }
        if(cache[i].time > max){
            max = cache[i].time;
            index = i;
        }
        pthread_rwlock_unlock(&(cache[i].lock));//unlock
    }
    return index;
}
/* $end find_evict */

/*
 *write_cache - write conntents into cache, use LRU  
 *            
 */
/* $begin write_cache */
void write_cache(char *sig, char *buf, size_t size){
    int index = find_evict();
    pthread_rwlock_wrlock(&(cache[index].lock));//lock
    strcpy(cache[index].sig, sig);
    memcpy(cache[index].buf, buf, size);
    cache[index].size = size;
    cache[index].valid = 1;
    cache[index].time = 0;
    for(int i = 0; i < CACHE_CNT; i++){
        cache[i].time++;
    }
    pthread_rwlock_unlock(&(cache[index].lock));//unlock
}
/* $end write_cache */
